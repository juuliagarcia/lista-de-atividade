soma = 0
contador = 0
i = 2
while contador < 50:
    soma += i
    i += 2
    contador += 1
print(soma)