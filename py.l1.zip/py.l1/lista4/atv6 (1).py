inferior = int(input("Digite o limite inferior: "))
superior = int(input("Digite o limite superior: "))
incremento = int(input("Digite o incremento: "))
i = inferior
while i <= superior:
    print(i)
    i += incremento