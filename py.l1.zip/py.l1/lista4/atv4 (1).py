n = int(input("Insira o valor de N: "))
soma = 0
i = 0
while i < n:
    soma += 2*i
    i += 1
print("A soma dos", n, "primeiros números pares é:", soma)