letra1 = input("informe a primeira letra: ")
letra2 = input("informe a segunda letra: ")

print(f" O usuário digitou {letra1} e {letra2}!.")