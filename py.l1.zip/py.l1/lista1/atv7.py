base = int(input("Coloque o valor da base: "))
altura = int(input("Coloque o valor da altura: "))

print("O perimetro é: ", (base + base + altura + altura))
print(" A área é: ", (base * altura))