primeirot = int(input("Digite o primeiro termo: "))
razao = int(input("Digite o valor da Razão: "))
n = 10 
an = primeirot * razao**(n-1)
print("O décimo termo da PG é: ", an)