repita = true 

While repita == true

    razao = int(input ("Informe a razão: "))
    primeiro = int(input("valor do primeiro termo da sequência: "))

    decimotermo = (primeiro) + (razao*9)
    print(decimotermo, "o valor ndo décimo termo é: \n")
    op2 = int(input("Deseja repetir? \n1- Sim \n2- Não"))

    if op2 == 1:
        repita = true
    else: 
        repita = false