repita = true 

While repita == true
    razao = input("Insira um númer com 3 digitos: ")
    soma = int(razao) + int(razao[2] + razao[1] +razao[0])
    soma = str(soma)

    somap = int(input[0]) *1
    somap = somap +(int(soma[1])*2)
    somap = somap +(int(soma[2])*3)

    somap = str (somap)
    print("O digito é ", somap[1])

    op2 = int(input("Deseja repetir?\n1- Sim\n2- Não"))

    if op2 == 1:
        repita = true
    else:
        repita = false