CDU = input("Digite um número: ")
print("O inverso do número é: ", CDU[2], CDU[1], CDU[0])