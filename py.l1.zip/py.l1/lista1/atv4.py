CDU = input("Digite um número: ")

print(" A centena é:" , CDU[0])

print(" A dezena é:" , CDU[1])

print(" A unidade é:" , CDU[2])