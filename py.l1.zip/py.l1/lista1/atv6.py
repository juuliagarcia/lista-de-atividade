repita = true 

While repita == true

    salario = int(input (" Informe o valor do seu salário minimo: "))
    quilowatts = int(input("Informe a quantia de quilowatts gastos em sua residência: "))

    razao = (salario/quilowatts)
    umwatts = (salario/700)

    valordacontainicial = (umwatts*quilowatts)
    valorcomdesconto = (valordacontainicial*0.90)

    print(umwatts, "esse é o valor de cada quilowatts gasto por essa residência. \n")
    print(valordacontainicial, "esse é o valor de reais a ser pago (sem os 10 por cento de desconto). \n")
    print(valorcomdesconto, "esse é o valor de reais a ser pago (com os 10 por cento de desconto). \n")
    op2 = int(input("Deseja repetir?\n1-Sim\n2-Não"))
     
    if op2==1:
        repita = true
    else:
        repita = false
