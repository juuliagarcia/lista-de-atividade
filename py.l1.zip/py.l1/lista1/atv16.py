repita = true 

While repita == true
 
    valor = int(input("Informe o valor: "))
    taxa = int(input("Informe a taxa: "))
    tempo = int(input("Informe o tempo: "))

    prestacao = (valor)+(valor*(taxa/100) * tempo)

    print("R$", prestacao, "esse é o valor da prestação deste funcionário. \n")
    
    op2 = int(input("Deseja repetir?\n1- Sim\n2- Não"))

    if op2 ==1:
        repita = true
    else:
        repita = false