num1 = int(input("informe um número: "))
print (num1 - 1)
print (num1 + 1)