repita = true 

While repita == true

    a = int(input("Informe o valor de A: "))
    b = int(input("Informe o valor de B: "))

    a,b = b,A

    op2 = int(input("Deseja repetir?\n1- Sim\n2- Não"))

    if op2 == 1:
        repita = true
    else:
        repita = false