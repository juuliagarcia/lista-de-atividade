num1 = int(input("informe um número: "))
print(num1*num1)
